package com.example.myfirstapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Register extends AppCompatActivity implements View.OnClickListener{
    EditText fName,lName,email,pass,cPass;
    Button btnRegister, btnCancel;
    User userData;
    FirebaseAuth firebaseAuth;
    ShowData_Fragment showDataInFragment= new ShowData_Fragment();
    PhoneVerificationFragment phoneVerificationFragment=new PhoneVerificationFragment();
    Bundle dataBundle= new Bundle();
    FragmentManager fragManger=getSupportFragmentManager();
    final FragmentTransaction fragTrans=fragManger.beginTransaction();
    private  EditText phoneNumber;
    private Button btnChoose, btnUpload;
    ProgressDialog progress;
    ProgressBar progressBar;
    private ImageView profileImageView;
    FirebaseStorage firebasestorage;
    StorageReference firebaseStorageReference;
    DatabaseReference firebaseDatabaseRef;
    private Uri filePath;
    EditText imagename;
    private String imageUploadId;
    private StorageTask uploadImageTask;
    private String radioCheckedValues;
    private static final int PICK_IMAGE_REQUEST = 1;
    private String datePicker;
    private RadioGroup sexSelectorGroup;
    private RadioButton radioMale, radioFemale, radioDiverse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Toast.makeText(Register.this,"FireBase Connected successfully ", Toast.LENGTH_SHORT).show();

        fName = (EditText) findViewById(R.id.firstName);
        lName = (EditText) findViewById(R.id.lastName);
        email = (EditText) findViewById(R.id.enterEmail);
        pass = (EditText) findViewById(R.id.enterPassword);
        cPass = (EditText) findViewById(R.id.confirmPassword);
        phoneNumber=(EditText) findViewById(R.id.phoneMobile);
        imagename=(EditText) findViewById(R.id.imageName);
        btnRegister =  (Button) findViewById(R.id.btnConfirm);
        btnCancel =  (Button) findViewById(R.id.btnCancel);
        btnChoose = (Button) findViewById(R.id.btnChoose);
        btnUpload = (Button) findViewById(R.id.btnUpload);
        progressBar = (ProgressBar) findViewById(R.id.progress_bar );
        profileImageView = (ImageView) findViewById(R.id.profileImgView);
        final ImageView logoImage = (ImageView) findViewById(R.id.logoImg);
        radioMale = (RadioButton) findViewById(R.id.radio_male);
        radioFemale = (RadioButton) findViewById(R.id.radio_female);
        radioDiverse = (RadioButton) findViewById(R.id.radio_diverse);
        sexSelectorGroup= (RadioGroup) findViewById(R.id.sexBtnGroup);

        //imagename.setVisibility(View.GONE);
        userData = new User();
        firebaseAuth =FirebaseAuth.getInstance();
        firebasestorage= FirebaseStorage.getInstance();
        firebaseStorageReference=firebasestorage.getReference("User");
        firebaseDatabaseRef = FirebaseDatabase.getInstance().getReference("User");
        btnCancel.setOnClickListener(this);
        progress = new ProgressDialog(this);
        progress.setTitle("Please Wait!!");
        progress.setMessage("Wait!!");
        progress.setCancelable(true);
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.show();
        Runnable progressRunnable = new Runnable() {

            @Override
            public void run() {
                progress.cancel();
            }
        };

        Handler pdCanceller = new Handler();
        pdCanceller.postDelayed(progressRunnable, 1000);

        sexSelectorGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (radioMale.isChecked()){
                    radioCheckedValues = "Male";
                }
                else if (radioFemale.isChecked()){
                    radioCheckedValues = "Female";
                }
                else if (radioDiverse.isChecked()){
                    radioCheckedValues = "Diverse";
                }
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Register.this, FinalSignUp.class);
                intent.putExtra("name", fName.getText().toString() +" " +lName.getText().toString());
                intent.putExtra("uEmail", email.getText().toString().trim());
                intent.putExtra("uPassword", pass.getText().toString().trim());
                intent.putExtra("uPhoneNumber", phoneNumber.getText().toString().trim());
                intent.putExtra("uGender", radioCheckedValues.trim());
                startActivity(intent);

            }
        });
        /*btnChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
                logoImage.setVisibility(View.GONE);
                profileImageView.setVisibility(View.VISIBLE);
                btnChoose.setVisibility(View.GONE);
                btnUpload.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.VISIBLE);

            }
        });

        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uploadImageTask != null && uploadImageTask.isInProgress()){
                    Toast.makeText(Register.this, "Upload in progress", Toast.LENGTH_SHORT).show();
                }
                else {
                    uploadImage();
                }
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String nameToDb = fName.getText().toString() +" " +lName.getText().toString();
                final String uemail = email.getText().toString().trim();
                final String upass = pass.getText().toString().trim();
                final String confirmPass = cPass.getText().toString().trim();
                final String mobileNumber = phoneNumber.getText().toString().trim();
                //final String nameImage= userData.getUserProfilePicName();
                //final String imageUrl= userData.getUserProfilePicUrl();
                *//*if (fName.getText().toString().isEmpty()){
                    fName.setError("Enter First Name");
                    fName.requestFocus();
                    return;
                }
                else if (lName.getText().toString().isEmpty()){
                    lName.setError("Enter Last Name");
                    lName.requestFocus();
                    return;
                }
                if (uemail.isEmpty()){
                   email.setError("Enter Email");
                   email.requestFocus();
                   return;
                }

                if (Patterns.EMAIL_ADDRESS.matcher(uemail).matches()){
                    email.setError("Enter Valid Email");
                    email.requestFocus();
                    return;
                }
                if (upass.isEmpty()){
                    pass.setError("Enter Password");
                    pass.requestFocus();
                    return;
                }
                if (confirmPass.isEmpty()){
                    cPass.setError("Enter Confirm Password");
                    cPass.requestFocus();
                    return;
                }
                if (confirmPass != upass){
                    cPass.setError("Entry must match with Password");
                    cPass.requestFocus();
                    return;
                }*//*

               *//* if(mobile.isEmpty() || mobile.length() < 10){
                    phoneNumber.setError("Enter a valid mobile");
                    phoneNumber.requestFocus();
                    return;
                }
                dataBundle.putString("phoneNumber ", mobile);
                phoneVerificationFragment.setArguments(dataBundle);
                fragTrans.add(R.id.fragment_container,phoneVerificationFragment);
                fragTrans.commit();*//*

                firebaseAuth.createUserWithEmailAndPassword(uemail,upass)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            //progress.show();
                            if (task.isSuccessful()){
                                //User user= new User();
                                Log.i(" Name ",nameToDb);
                                Log.i(" Email ",uemail);
                                Log.i(" Password ",upass);
                                Log.i(" Phone Number ",mobileNumber);
                                //Toast.makeText(Register.this,"Data Inserted ",Toast.LENGTH_SHORT).show();
                                userData.setUserName(nameToDb);
                                userData.setUserEmail(uemail);
                                userData.setUserPassword(upass);
                                userData.setUserPhoneNumber(mobileNumber);
                                userData.setSex(radioCheckedValues);
                                //String newUserId= FirebaseDatabase.getInstance().getReference().push().getKey();
                                String newUserId= firebaseDatabaseRef.push().getKey();
                                //FirebaseDatabase.getInstance().getReference().child(newUserId).setValue(userData);
                                firebaseDatabaseRef.child(newUserId).setValue(userData);
                                firebaseDatabaseRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(userData).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()){
                                            Toast.makeText(Register.this,"Data Inserted Successfully",Toast.LENGTH_SHORT).show();

                                            dataBundle.putString("name", userData.getUserName());
                                            dataBundle.putString("email", userData.getUserEmail());
                                            dataBundle.putString("password", userData.getUserPassword());
                                            dataBundle.putString("phoneNumber", userData.getUserPhoneNumber());
                                            dataBundle.putString("imageUrl", userData.getUserProfilePicUrl());
                                            //progress.dismiss();
                                            showDataInFragment.setArguments(dataBundle);
                                            btnCancel.setVisibility(View.GONE);
                                            btnRegister.setVisibility(View.GONE);
                                            btnChoose.setVisibility(View.GONE);
                                            btnUpload.setVisibility(View.GONE);
                                            fragTrans.add(R.id.fragment_container,showDataInFragment);
                                            fragTrans.commit();
                                        }
                                    }
                                });
                                *//*FirebaseDatabase.getInstance().getReference().child("User").child(FirebaseAuth.getInstance()
                                        .getCurrentUser().getUid()).setValue(userData).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()){
                                            Toast.makeText(Register.this,"Data Inserted Successfully",Toast.LENGTH_SHORT).show();

                                            dataBundle.putString("name", userData.getUserName());
                                            dataBundle.putString("email", userData.getUserEmail());
                                            dataBundle.putString("password", userData.getUserPassword());
                                            dataBundle.putString("phoneNumber", userData.getUserPhoneNumber());
                                            dataBundle.putString("imageUrl", userData.getUserProfilePicUrl());
                                            //progress.dismiss();
                                            showDataInFragment.setArguments(dataBundle);
                                            //btnCancel.setVisibility(View.GONE);
                                            //btnRegister.setVisibility(View.GONE);
                                            fragTrans.add(R.id.fragment_container,showDataInFragment);
                                            fragTrans.commit();
                                        }


                                    }
                                });*//*
                            }
                            else{
                                Toast.makeText(Register.this,task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            }

                        }
                    });

              *//*  if (nameToDb != null && uemail.length()!=0 && upass.length() >= 3){
                   // User userObj=new User();
                    String id= firebaseRef.push().getKey();
                    userData.setuId(id);
                    userData.setUserName(nameToDb);
                    userData.setUserEmail(uemail);
                    userData.setUserPassword(upass);
                    Log.i("Name", userData.getUserName());
                    Log.i("Email", userData.getUserEmail());
                    Log.i("Password", userData.getUserPassword());
                    //firebaseRef.child("userObj").child(userid).child("Name").setValue(nameToDb);
                    firebaseRef.child(id).setValue(userData);
                    AddAuthentication(uemail,upass,nameToDb);

                    Toast.makeText(Register.this, "Data Inserted Successfully ",Toast.LENGTH_SHORT).show();
                    dataBundle.putString("name", userData.getUserName());
                    dataBundle.putString("email", userData.getUserEmail());
                    dataBundle.putString("password", userData.getUserPassword());
                    showDataInFragment.setArguments(dataBundle);
                }
                btnCancel.setVisibility(View.GONE);
                btnRegister.setVisibility(View.GONE);
                fragTrans.add(R.id.fragment_container,showDataInFragment);
                fragTrans.commit();*//*
            }
        });

    }*/

   /* private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null ){
            filePath = data.getData();
            Picasso.get().load(filePath).into(profileImageView);
            *//*try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                profileImageView.setImageBitmap(bitmap);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }*//*
        }
    }
    //For image extension e.g. .jpg or .png
    private  String getFileExtension(Uri uri){
        ContentResolver cr = getContentResolver();
        MimeTypeMap mimeTypeMap=MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }
    private void uploadImage() {
        if(filePath != null){
            StorageReference ref = firebaseStorageReference.child(System.currentTimeMillis()
            + "." + getFileExtension(filePath));
            uploadImageTask=ref.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Handler handler=new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    progressBar.setProgress(0);
                                }
                            }, 2000);
                            //progressDialog.dismiss();
                            Toast.makeText(Register.this, "Uploaded", Toast.LENGTH_SHORT).show();
                            userData.setUserProfilePicName(imagename.getText().toString().trim());
                            userData.setUserProfilePicUrl(taskSnapshot.getStorage().getDownloadUrl().toString());
                           // imageUploadId = FirebaseDatabase.getInstance().getReference().push().getKey();
                            //FirebaseDatabase.getInstance().getReference().child(imageUploadId).setValue(user);
                           // Log.i("  Image ID ", imageUploadId);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            //progressBar.dismiss();
                            Toast.makeText(Register.this, "Failed "+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot
                                    .getTotalByteCount());
                            progressBar.setProgress((int)progress);
                        }
                    });
        }
        else {
            Toast.makeText(this,"No file selected", Toast.LENGTH_SHORT).show();
        }*/
    }

    /*private void AddAuthentication(final String uEmail, final String uPass, final String uName) {
        firebaseAuth.createUserWithEmailAndPassword(uEmail,uPass)
            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        //User user= new User();
                        userData.setUserName(uPass);
                        userData.setUserEmail(uEmail);
                        userData.setUserPassword(uPass);
                        database.getReference().child("User").child(FirebaseAuth.getInstance()
                                .getCurrentUser().getUid()).setValue(userData).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(Register.this,"Data Inserted Successfully",Toast.LENGTH_SHORT).show();

                                    dataBundle.putString("name", userData.getUserName());
                                    dataBundle.putString("email", userData.getUserEmail());
                                    dataBundle.putString("password", userData.getUserPassword());
                                    showDataInFragment.setArguments(dataBundle);
                                    fragTrans.add(R.id.fragment_container,showDataInFragment);
                                    fragTrans.commit();
                                }


                            }
                        });
                    }
                    else{
                        Toast.makeText(Register.this,task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                    }

                }
            });
    }*/


    private boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches()){
            toastMessage("please enter valid Email ");

        }
        return matcher.matches();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnCancel:
                startActivity(new Intent(this, Dashboard.class));
                break;
        }
    }
    // add data to database from activity
   /* public void addData(String name, String email, String password){

        boolean insertDataToDatabase = databaseHelper.addData(name, email, password);

        if (insertDataToDatabase)
            toastMessage("Successfully Registered");
        else
            toastMessage("SomeThing Went Wrong");

    }*/

    private void toastMessage(String message) {

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


    /*public void onRadioButtonClicked(View view) {
        radioMale.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                radioCheckedValues = "Male";
            }
        });
        radioFemale.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                radioCheckedValues = "Female";
            }
        });
        radioDiverse.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                radioCheckedValues = "Diverse";
            }
        });

    }*/
}
