package com.example.myfirstapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class showproducts extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AllProducts allProductsAdapter;
    private List<Products> productsList;
    private DatabaseReference mDatabaseRef;
    private FirebaseAuth mFirebaseAuth;
    private Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.productslist);

        //btnLogin = findViewById(R.id.showProductToLogin);
        recyclerView=findViewById(R.id.productsListRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        productsList=new ArrayList<>();

        mDatabaseRef= FirebaseDatabase.getInstance().getReference("Products");
        mFirebaseAuth=FirebaseAuth.getInstance();
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot productsDataSnapshot:dataSnapshot.getChildren()){
                    Products products=productsDataSnapshot.getValue(Products.class);
                    productsList.add(products);
                    allProductsAdapter=new AllProducts(showproducts.this,productsList);
                    recyclerView.setAdapter(allProductsAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(showproducts.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
        /*btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(showproducts.this,SignIn.class);
                startActivity(intent);
            }
        });*/
    }
}
