package com.example.myfirstapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignIn extends AppCompatActivity implements View.OnClickListener {
    Button btnSignIn, btnsignOut,loginFb,btnProfile;
    EditText email,pass;
    TextView forgetPassword;
    public  static  final String id="-LtvYIg-vEh0iY78nmOJ";
    private LoginButton FacebookButton;
    private CircleImageView circleImageView;
    private TextView txtFbName,txtFbEmail;
    private CallbackManager callBackManager;
    private ProgressDialog progressDialog;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    DatabaseReference firebaseRef,refToPointNode;
    FirebaseAuth firebaseAuth;
    FirebaseAuth.AuthStateListener firebaseAuthListener;
    User verifyUser;
    List<User> userList;
    ProgressDialog progress;
    private String loginEmail;
    private String loginPassword;
    private  ShowData_Fragment showData_fragment;
    private FragmentManager fragManger;
    private FragmentTransaction fragTrans;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(this.getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        email = (EditText) findViewById(R.id.enterEmail);
        pass = (EditText) findViewById(R.id.enterLoginPassword);
        txtFbEmail = findViewById(R.id.profile_email);
        txtFbName =  findViewById(R.id.enterLoginPassword);
        circleImageView = findViewById(R.id.profile_pic);
        forgetPassword =(TextView) findViewById(R.id.forgetLoginPassword);

        btnsignOut = (Button) findViewById(R.id.btnSignOut);
        btnSignIn = (Button) findViewById(R.id.btnLogin);
        btnProfile = (Button) findViewById(R.id.btnProfile);
        FacebookButton = (LoginButton) findViewById(R.id.fb_login_button);

        showData_fragment = new ShowData_Fragment();
        fragManger=getSupportFragmentManager();
        fragTrans=fragManger.beginTransaction();

        progress = new ProgressDialog(this);
        progress.setTitle("Please Wait!!");
        progress.setMessage("Wait!!");
        progress.setCancelable(true);
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);

        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(SignIn.this,forgetPassword.class);
                startActivity(intent);
            }
        });

        userList = new ArrayList<User>();
        verifyUser = new User();
        //database reference pointing to root of database
        firebaseRef= database.getInstance().getReference("User");
        //database reference pointing to User node
        refToPointNode = firebaseRef.child("User").child(id);
        firebaseAuth = FirebaseAuth.getInstance();
        btnProfile.setVisibility(View.GONE);
        /*if (!firebaseAuth.getCurrentUser().getUid().equals("")){
            btnProfile.setVisibility(View.VISIBLE);
        }*/


        callBackManager = CallbackManager.Factory.create();
        List<String> permissionNeeds = Arrays.asList("email", "public_profile");
        FacebookButton.setReadPermissions(permissionNeeds);
        checkLoginStatus();
        FacebookButton.registerCallback (callBackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {
                Log.v("FaceBook LoginActivity", error.getCause().toString());
            }
        });

        //btnSignIn.setOnClickListener(this);
        firebaseAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                FirebaseUser firebaseUser= firebaseAuth.getCurrentUser();
                if (firebaseUser!=null) {
                    Toast.makeText(SignIn.this, "Successfully Signed In with: " + firebaseUser.getEmail(), Toast.LENGTH_SHORT).show();

                }
                else
                    Toast.makeText(SignIn.this, "Successfully Signed Out: " ,Toast.LENGTH_SHORT).show();
            }
        };

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginEmail= email.getText().toString().trim();
                loginPassword= pass.getText().toString().trim();

                if (!loginEmail.equals("") && !loginPassword.equals("")){

                    firebaseAuth.signInWithEmailAndPassword(loginEmail,loginPassword)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(SignIn.this,"Congrats!",Toast.LENGTH_SHORT).show();
                                    //Intent intent = new Intent(SignIn.this, ShowData.class);
                                    //Intent intent = new Intent(SignIn.this, UserProfile.class);
                                    Intent intent = new Intent(SignIn.this, uploadproduct.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                }
                                else{
                                    Toast.makeText(SignIn.this,"Please check Email or Password",Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    /*fragTrans.add(R.id.fragment_container,showData_fragment);
                    fragTrans.commit();*/

                }
                else {
                    Toast.makeText(SignIn.this, "Please enter valid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignIn.this,ShowData.class);
                startActivity(intent);
            }
        });
        btnsignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firebaseAuth.signOut();
                Toast.makeText(SignIn.this,"Signing Out...",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(SignIn.this, Dashboard.class);
                startActivity(intent);


            }
        });
    }


    @Override
    public void onStart() {
        super.onStart();
        firebaseAuth.addAuthStateListener(firebaseAuthListener);
    }
    @Override
    public void onStop() {
        super.onStop();
        if (firebaseAuthListener != null){
            firebaseAuth.removeAuthStateListener(firebaseAuthListener);
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnCancel:
                startActivity(new Intent(this, Dashboard.class));
                break;
        }
        /*switch (v.getId()){
            case R.id.btnLogin:
                logIn();
                break;
        }*/
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callBackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
    AccessTokenTracker tokenTracker = new AccessTokenTracker() {
        @Override
        protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken currentAccessToken) {

        }
    };
    private void loadUserProfile(AccessToken newAccessToken){

        final GraphRequest request= GraphRequest.newMeRequest(newAccessToken, new GraphRequest.GraphJSONObjectCallback() {
            @Override
            public void onCompleted(JSONObject object, GraphResponse response) {
                try {
                    String firstName=object.getString("first_name");
                    String lastName=object.getString("last_name");
                    String email=object.getString("email");
                    String id=object.getString("id");
                    String imageUrl="https://graphfacebook.com/"+id+"/picture?type=normal";

                    txtFbEmail.setText(email);
                    txtFbName.setText(firstName+" "+lastName);
                    RequestOptions requestOptions = new RequestOptions();
                    requestOptions.dontAnimate();

                    Glide.with(SignIn.this).load(imageUrl).into(circleImageView);
                }
                catch (JSONException e){
                    e.printStackTrace();
                }

            }
        });
        Bundle parameters= new Bundle();
        parameters.putString("fields","first_name,last_name,email,id");
        request.setParameters(parameters);
        request.executeAsync();
    }
    private void checkLoginStatus()
    {
        if(AccessToken.getCurrentAccessToken()!=null)
        {
            loadUserProfile(AccessToken.getCurrentAccessToken());
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
