package com.example.foodsharingapplication.authentication;


public class UserProfileAdapter {



}
