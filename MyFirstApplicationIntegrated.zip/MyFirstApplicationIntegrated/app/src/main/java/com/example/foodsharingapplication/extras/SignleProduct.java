package com.example.foodsharingapplication.extras;

public class SignleProduct {
    String pName;
    public SignleProduct() {
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }
}
