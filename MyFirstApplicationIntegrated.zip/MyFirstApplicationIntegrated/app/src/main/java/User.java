public class User {
    String password = "admin";
    String email = "admin";
    public void setPassword(String password){
        password = password;
    }
    public void setEmail(String email1){
        email = email1;
    }
    public String getPassword(){
        return password;
    }
    public String getEmail(){

        return email;
    }

}
